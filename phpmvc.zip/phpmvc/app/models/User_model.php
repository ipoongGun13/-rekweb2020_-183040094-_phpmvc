<?php  

class User_model {
	private $nama = 'Try';

	public function getUser() {
		return $this->nama;
	}
}